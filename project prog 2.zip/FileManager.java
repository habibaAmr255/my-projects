import java.io.*;
import java.util.ArrayList;
import java.util.List;

class FileManager {
    private static final String USERS_FILE = "users.txt";
    private static final String FLIGHTS_FILE = "flights.txt";
    private static final String BOOKINGS_FILE = "bookings.txt";
    private static final String PASSENGERS_FILE = "passengers.txt";
    public void saveUsers(List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users) {
                String userType = user instanceof Customer ? "Customer" : user instanceof Agent ? "Agent" : "Administrator";
                writer.write(userType + "," + user.getUserId() + "," + user.getUserName() + "," + user.getPassword() + "," + 
                            user.getName() + "," + user.getEmail() + "," + user.getContactInfo());
                if (user instanceof Customer) {
                    Customer c = (Customer) user;
                    writer.write("," + c.getCustomerId() + "," + c.getAddress() + "," + c.getPreferences());
                } else if (user instanceof Agent) {
                    Agent a = (Agent) user;
                    writer.write("," + a.getAgentId() + "," + a.getDepartment() + "," + a.getCommission());
                } else if (user instanceof Administrator) {
                    Administrator admin = (Administrator) user;
                    writer.write("," + admin.getAdminId() + "," + admin.getSecurityLevel());
                }
                writer.newLine();
            }
            System.out.println("Users saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving users: " + e.getMessage());
        }
    }

    public List<User> loadUsers() {
        List<User> users = new ArrayList<>();
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating users file: " + e.getMessage());
            }
            return users;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 7) {
                    System.out.println("Invalid user data skipped: " + line);
                    continue;
                }
                String userType = data[0];
                try {
                    if (userType.equals("Customer") && data.length >= 10) {
                        users.add(new Customer(data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9]));
                    } else if (userType.equals("Agent") && data.length >= 10) {
                        users.add(new Agent(data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], Double.parseDouble(data[9])));
                    } else if (userType.equals("Administrator") && data.length >= 9) {
                        users.add(new Administrator(data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8]));
                    } else {
                        System.out.println("Invalid user type or insufficient data: " + line);
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Error parsing user data: " + line + " - " + e.getMessage());
                }
            }
            System.out.println("Users loaded from file.");
        } catch (IOException e) {
            System.out.println("Error loading users: " + e.getMessage());
        }
        return users;
    }

    public void saveFlights(List<Flight> flights) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FLIGHTS_FILE))) {
            for (Flight flight : flights) {
                writer.write(flight.getFlightType() + "," + flight.getFlightNumber() + "," + flight.getAirline() + "," + 
                            flight.getOrigin() + "," + flight.getDestination() + "," + flight.getDepartureTime() + "," + 
                            flight.getArrivalTime() + "," + flight.getAvailableSeats() + "," + 
                            flight.calculatePrice("economy") + "," + flight.calculatePrice("business") + "," + 
                            flight.calculatePrice("first"));
                if (flight instanceof DomesticFlight) {
                    DomesticFlight domestic = (DomesticFlight) flight;
                    writer.write("," + domestic.getDomesticDiscount() + "," + domestic.getLuggageLimit());
                } else if (flight instanceof InternationalFlight) {
                    InternationalFlight international = (InternationalFlight) flight;
                    writer.write("," + international.getInternationalTax() + "," + String.join(";", international.getVisaRequirements()));
                }
                writer.newLine();
            }
            System.out.println("Flights saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving flights: " + e.getMessage());
        }
    }
    public List<Flight> loadFlights() {
        List<Flight> flights = new ArrayList<>();
        File file = new File(FLIGHTS_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating flights file: " + e.getMessage());
            }
            return flights;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 11) {
                    System.out.println("Invalid flight data skipped: " + line);
                    continue;
                }
                try {
                    String flightType = data[0];
                    String flightNumber = data[1];
                    String airline = data[2];
                    String origin = data[3];
                    String destination = data[4];
                    String departureTime = data[5];
                    String arrivalTime = data[6];
                    int availableSeats = Integer.parseInt(data[7]);
                    double[] prices = new double[]{
                        Double.parseDouble(data[8]),
                        Double.parseDouble(data[9]),
                        Double.parseDouble(data[10])
                    };

                    Flight flight = null;
                    if (flightType.equals("Domestic") && data.length >= 13) {
                        double domesticDiscount = Double.parseDouble(data[11]);
                        double luggageLimit = Double.parseDouble(data[12]);
                        flight = new DomesticFlight(flightNumber, airline, origin, destination, departureTime, arrivalTime, 
                                                   availableSeats, prices, domesticDiscount, luggageLimit);
                    } else if (flightType.equals("International") && data.length >= 13) {
                        double internationalTax = Double.parseDouble(data[11]);
                        flight = new InternationalFlight(flightNumber, airline, origin, destination, departureTime, arrivalTime, 
                                                        availableSeats, prices, internationalTax);
                        if (!data[12].isEmpty()) {
                            String[] visaRequirements = data[12].split(";");
                            for (String country : visaRequirements) {
                                ((InternationalFlight) flight).addVisaRequirement(country);
                            }
                        }
                    } else {
                        System.out.println("Invalid flight type or insufficient data: " + line);
                        continue;
                    }

                    flights.add(flight);
                } catch (NumberFormatException e) {
                    System.out.println("Error parsing flight data: " + line + " - " + e.getMessage());
                }
            }
            System.out.println("Flights loaded from file.");
        } catch (IOException e) {
            System.out.println("Error loading flights: " + e.getMessage());
        }
        return flights;
    }
    public void saveBookings(List<Booking> bookings) {
        File file = new File(BOOKINGS_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating bookings file: " + e.getMessage());
                return;
            }
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BOOKINGS_FILE))) {
            for (Booking booking : bookings) {
                String paymentStatus = booking.getPaymentStatus() != null ? booking.getPaymentStatus() : "Pending";
                writer.write(booking.getBookingReference() + "," + booking.getCustomer().getUserId() + "," + 
                            booking.getFlight().getFlightNumber() + "," + booking.getSeatSelection() + "," + 
                            booking.getStatus() + "," + paymentStatus + "," + booking.getSpecialRequests());
                writer.newLine();
            }
            System.out.println("Bookings saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving bookings: " + e.getMessage());
        }
    }

    public List<Booking> loadBookings(BookingSystem bookingSystem) {
        List<Booking> bookings = new ArrayList<>();
        File file = new File(BOOKINGS_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating bookings file: " + e.getMessage());
            }
            return bookings;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 7) {
                    System.out.println("Invalid booking data skipped: " + line);
                    continue;
                }
                String bookingReference = data[0];
                String userId = data[1];
                String flightNumber = data[2];
                String seatSelection = data[3];
                String status = data[4];
                String paymentStatus = data[5];
                String specialRequests = data[6];

                Customer customer = null;
                for (User user : bookingSystem.users) {
                    if (user.getUserId().equals(userId) && user instanceof Customer) {
                        customer = (Customer) user;
                        break;
                    }
                }

                Flight flight = null;
                for (Flight f : bookingSystem.flights) {
                    if (f.getFlightNumber().equals(flightNumber)) {
                        flight = f;
                        break;
                    }
                }

                if (customer != null && flight != null) {
                    Booking booking = new Booking(bookingReference, customer, flight, seatSelection, status, specialRequests);
                    booking.setPaymentStatus(paymentStatus);
                    bookings.add(booking);
                } else {
                    System.out.println("Skipping booking due to missing customer or flight: " + line);
                }
            }
            System.out.println("Bookings loaded from file.");
        } catch (IOException e) {
            System.out.println("Error loading bookings: " + e.getMessage());
        }
        return bookings;
    }

    public void savePassengers(List<Booking> bookings) {
        File file = new File(PASSENGERS_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating passengers file: " + e.getMessage());
                return;
            }
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PASSENGERS_FILE))) {
            for (Booking booking : bookings) {
                for (Passenger passenger : booking.getPassengers()) {
                    writer.write(passenger.getPassengerId() + "," + booking.getBookingReference() + "," +
                                passenger.getName() + "," + passenger.getPassportNumber() + "," +
                                passenger.getDateOfBirth() + "," + passenger.getSpecialRequests());
                    writer.newLine();
                }
            }
            System.out.println("Passengers saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving passengers: " + e.getMessage());
        }
    }
    public void loadPassengers(BookingSystem bookingSystem) {
        File file = new File(PASSENGERS_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating passengers file: " + e.getMessage());
            }
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 6) {
                    System.out.println("Invalid passenger data skipped: " + line);
                    continue;
                }
                String bookingReference = data[1];
                Passenger passenger = new Passenger(data[2], data[3], data[4], data[5]);
                for (Booking booking : bookingSystem.bookings) {
                    if (booking.getBookingReference().equals(bookingReference)) {
                        booking.addPassenger(passenger);
                        break;
                    }
                }
            }
            System.out.println("Passengers loaded and linked to bookings.");
        } catch (IOException e) {
            System.out.println("Error loading passengers: " + e.getMessage());
        }
    }
}