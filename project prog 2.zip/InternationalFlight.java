import java.util.ArrayList;
import java.util.List;

class InternationalFlight extends Flight {
    private List<String> visaRequirements; 
    private double internationalTax; 

    public InternationalFlight(String flightNumber, String airline, String origin, String destination, String departureTime, 
                              String arrivalTime, int availableSeats, double[] prices, double internationalTax) {
        super(flightNumber, airline, origin, destination, departureTime, arrivalTime, availableSeats, prices);
        this.visaRequirements = new ArrayList<>();
        this.internationalTax = internationalTax;
    }

    public void addVisaRequirement(String country) {
        if (country != null && !country.trim().isEmpty()) {
            visaRequirements.add(country);
            System.out.println("Visa requirement for " + country + " added to flight: " + flightNumber);
        } else {
            System.out.println("Invalid country name.");
        }
    }

    public boolean hasVisaRequirement(String country) {
        return visaRequirements.contains(country);
    }

    public boolean checkPassportValidity(String expiryDate) {
        if (expiryDate == null || !expiryDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
            System.out.println("Invalid passport expiry date format. Use YYYY-MM-DD.");
            return false;
        }

        String currentDate = "2025-05-12"; 
        String departureDate = departureTime.split(" ")[0]; 
        if (expiryDate.compareTo(currentDate) <= 0) {
            System.out.println("Passport has expired for flight: " + flightNumber);
            return false;
        }

        int expiryYear = Integer.parseInt(expiryDate.split("-")[0]);
        int expiryMonth = Integer.parseInt(expiryDate.split("-")[1]);
        int departureYear = Integer.parseInt(departureDate.split("-")[0]);
        int departureMonth = Integer.parseInt(departureDate.split("-")[1]) + 6; 
        if (departureMonth > 12) {
            departureYear += 1;
            departureMonth -= 12;
        }

        if (expiryYear < departureYear || (expiryYear == departureYear && expiryMonth < departureMonth)) {
            System.out.println("Passport expires within 6 months of departure for flight: " + flightNumber);
            return false;
        }

        System.out.println("Passport is valid for international flight: " + flightNumber);
        return true;
    }

    public double getInternationalTax() {
        return internationalTax;
    }

    public void setInternationalTax(double internationalTax) {
        if (internationalTax < 0) {
            System.out.println("International tax cannot be negative.");
            return;
        }
        this.internationalTax = internationalTax;
        System.out.println("International tax set successfully.");
    }

    @Override
    public double calculatePrice(String seatClass) {
        double basePrice = super.calculatePrice(seatClass);
        return basePrice + internationalTax;  
    }

    public List<String> getVisaRequirements() {
        return visaRequirements;
    }
}