class Aircraft {
    private String aircraftId;
    private String model;
    private int capacity;

    public Aircraft(String aircraftId, String model, int capacity) {
        this.aircraftId = aircraftId;
        this.model = model;
        this.capacity = capacity;
    }

    public String getAircraftId() {
        return aircraftId;
    }

    public String getModel() {
        return model;
    }

    public int getCapacity() {
        return capacity;
    }
}