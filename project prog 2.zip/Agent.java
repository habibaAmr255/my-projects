import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

class Agent extends User {
    private String agentId;
    private String department;
    private double commission;

    public Agent(String userId, String userName, String password, String name, String email, String contactInfo, 
                 String agentId, String department, double commission) {
        super(userId, userName, password, name, email, contactInfo);
        this.agentId = agentId;
        this.department = department;
        this.commission = commission;
    }

    public boolean setAgentId(String agentId) {
        if (agentId == null || agentId.trim().isEmpty()) {
            System.out.println("Agent ID cannot be null or empty.");
            return false; 
        }
        this.agentId = agentId;
        System.out.println("Agent ID set successfully.");
        return true;
    }

    public String getAgentId() {
        return agentId;
    }

    public boolean setDepartment(String department) {
        if (department == null || department.trim().isEmpty()) {
            System.out.println("Department cannot be null or empty.");
            return false;
        }
        this.department = department;
        System.out.println("Department set successfully.");
        return true;
    }

    public String getDepartment() {
        return department;
    }

    public boolean setCommission(double commission) {
        if (commission < 0) {
            System.out.println("Commission cannot be negative.");
            return false;
        }
        this.commission = commission;
        System.out.println("Commission set successfully.");
        return true;
    }

    public double getCommission() {
        return commission;
    }

    public void manageFlights() {
        System.out.println("Managing flights for agent: " + getName());
    }

    public void createBookingForCustomer(Customer customer, Flight flight, String seatSelection, String specialRequests, Booking booking) {
        for (Booking existingBooking : customer.getBookingHistory()) {
            if (existingBooking.getFlight().getFlightNumber().equals(flight.getFlightNumber()) && 
                (existingBooking.getStatus().equals("Reserved") || existingBooking.getStatus().equals("Confirmed"))) {
                System.out.println("Error: Customer already has a booking for flight " + flight.getFlightNumber());
                return;
            }
        }

        if (flight.reserveSeat(seatSelection)) {
            customer.getBookingHistory().add(booking);
            System.out.println("Booking created by agent for customer: " + customer.getName());
        } else {
            System.out.println("Cannot create booking: Seat not available.");
        }
    }

    public void modifyBooking(String bookingReference, String newSeatSelection) {
        System.out.println("Booking " + bookingReference + " modified with new seat: " + newSeatSelection);
    }

    public void generateReports() {
        System.out.println("Generating reports for agent: " + getName());
    }

    @Override
    public void updateProfile() {
        System.out.println("Agent profile updated successfully for: " + getName());
    }

    private String generateBookingReference() {
        int randomNum = 100000 + (int)(Math.random() * 900000); 
        return String.format("%06d", randomNum); 
    }

    @Override
    public void showMenu(BookingSystem system, Scanner scanner) {
        while (true) {
            System.out.println("---- Agent Menu ----");
            System.out.println("1. Add Flight");
            System.out.println("2. Update Flight");
            System.out.println("3. Create Booking for Customer");
            System.out.println("4. Modify Booking");
            System.out.println("5. Generate Reports");
            System.out.println("6. Logout");
            System.out.print("Choose: ");
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                System.out.print("Flight Number: ");
                String flightNumber = scanner.nextLine();
                for (Flight f : system.flights) {
                    if (f.getFlightNumber().equals(flightNumber)) {
                        System.out.println("Flight number already exists.");
                        continue;
                    }
                }

                System.out.print("Airline: ");
                String airline = scanner.nextLine();
                System.out.print("Origin: ");
                String origin = scanner.nextLine();
                System.out.print("Destination: ");
                String destination = scanner.nextLine();
                if (origin.equalsIgnoreCase(destination)) {
                    System.out.println("Origin & destination cannot be same.");
                    return;
                }
                System.out.print("Departure Time (YYYY-MM-DD HH:MM): ");
                String departure = scanner.nextLine();
                System.out.print("Arrival Time (YYYY-MM-DD HH:MM): ");
                String arrival = scanner.nextLine();
                System.out.print("Seats: ");
                int seats;
                try {
                    seats = Integer.parseInt(scanner.nextLine());
                    if (seats <= 0) {
                        System.out.println("Number of seats must be positive.");
                        continue;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid number of seats.");
                    continue;
                }
                System.out.print("Economy Price: ");
                double economy;
                try {
                    economy = Double.parseDouble(scanner.nextLine());
                    if (economy <= 0) {
                        System.out.println("Price must be positive.");
                        continue;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid price value.");
                    continue;
                }
                double[] prices = {economy, economy * 1.5, economy * 2};

                System.out.print("Flight Type (Domestic/International): ");
                String flightType = scanner.nextLine().trim();
                Flight flight = null;

                if (flightType.equalsIgnoreCase("Domestic")) {
                    System.out.print("Domestic Discount (e.g., 0.1 for 10%): ");
                    double domesticDiscount;
                    try {
                        domesticDiscount = Double.parseDouble(scanner.nextLine());
                        if (domesticDiscount < 0 || domesticDiscount > 1) {
                            System.out.println("Invalid discount value. Must be between 0 and 1.");
                            continue;
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid discount value.");
                        continue;
                    }
                    System.out.print("Luggage Limit (kg): ");
                    double luggageLimit;
                    try {
                        luggageLimit = Double.parseDouble(scanner.nextLine());
                        if (luggageLimit <= 0) {
                            System.out.println("Luggage limit must be positive.");
                            continue;
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid luggage limit value.");
                        continue;
                    }
                    flight = new DomesticFlight(flightNumber, airline, origin, destination, departure, arrival, seats, prices, domesticDiscount, luggageLimit);
                } else if (flightType.equalsIgnoreCase("International")) {
                    System.out.print("International Tax (e.g., 50.0): ");
                    double internationalTax;
                    try {
                        internationalTax = Double.parseDouble(scanner.nextLine());
                        if (internationalTax < 0) {
                            System.out.println("International tax cannot be negative.");
                            continue;
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid international tax value.");
                        continue;
                    }
                    flight = new InternationalFlight(flightNumber, airline, origin, destination, departure, arrival, seats, prices, internationalTax);
                    System.out.print("Add Visa Requirement (Country name, press Enter to skip): ");
                    String visaCountry = scanner.nextLine().trim();
                    if (!visaCountry.isEmpty()) {
                        ((InternationalFlight) flight).addVisaRequirement(visaCountry);
                    }
                } else {
                    System.out.println("Invalid flight type. Choose 'Domestic' or 'International'.");
                    continue;
                }

                system.flights.add(flight);
                system.saveData();
                System.out.println("Flight added successfully: " + flightNumber + " (" + flight.getFlightType() + ")");
            } else if (choice.equals("2")) {
                System.out.print("Flight Number: ");
                String flightNumber = scanner.nextLine();
                for (Flight f : system.flights) {
                    if (f.getFlightNumber().equals(flightNumber)) {
                        System.out.print("New Departure Time: ");
                        String departure = scanner.nextLine();
                        System.out.print("New Arrival Time: ");
                        String arrival = scanner.nextLine();
                        f.updateSchedule(departure, arrival);
                        system.saveData();
                        System.out.println("Flight updated successfully.");
                        return;
                    }
                }
                System.out.println("Flight not found.");
            } else if (choice.equals("3")) {
                System.out.print("Customer ID: ");
                String customerId = scanner.nextLine();
                Customer customer = null;
                for (User user : system.getUsers()) {
                    if (user instanceof Customer && ((Customer) user).getCustomerId().equals(customerId)) {
                        customer = (Customer) user;
                        break;
                    }
                }
                if (customer == null) {
                    System.out.println("Customer not found.");
                    continue;
                }
                System.out.print("Origin: ");
                String origin = scanner.nextLine();
                System.out.print("Destination: ");
                String destination = scanner.nextLine();
                System.out.print("Date (YYYY-MM-DD): ");
                String date = scanner.nextLine();
                List<Flight> flights = system.searchFlights(origin, destination, date);
                if (flights.isEmpty()) {
                    System.out.println("No flights found.");
                    continue;
                }
                System.out.println("Available Flights:");
                System.out.println("+-----+---------------+-------------+-------------------+");
                System.out.println("| No  | Flight Number | Airline     | Departure Time    |");
                System.out.println("+-----+---------------+-------------+-------------------+");
                for (int i = 0; i < flights.size(); i++) {
                    Flight f = flights.get(i);
                    System.out.printf("| %-3d | %-13s | %-11s | %-17s |\n", 
                        i + 1, f.getFlightNumber(), f.getAirline(), f.getDepartureTime());
                }
                System.out.println("+-----+---------------+-------------+-------------------+");
                System.out.print("Select flight: ");
                int flightChoice;
                try {
                    flightChoice = Integer.parseInt(scanner.nextLine()) - 1;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    continue;
                }
                if (flightChoice < 0 || flightChoice >= flights.size()) {
                    System.out.println("Invalid selection.");
                    continue;
                }
                Flight flight = flights.get(flightChoice);
                System.out.print("Seat Class (economy/business/first): ");
                String seatClass = scanner.nextLine().toLowerCase();
                if (!seatClass.equals("economy") && !seatClass.equals("business") && !seatClass.equals("first")) {
                    System.out.println("Invalid seat class.");
                    continue;
                }
                List<String> availableSeats = flight.getAvailableSeatsByClass(seatClass);
                if (availableSeats.isEmpty()) {
                    System.out.println("No seats available in " + seatClass + " class.");
                    continue;
                }
                System.out.println("Available Seats in " + seatClass + ":");
                for (int i = 0; i < availableSeats.size(); i++) {
                    System.out.println((i + 1) + ". " + availableSeats.get(i));
                }
                System.out.print("Select seat (number): ");
                int seatChoice;
                try {
                    seatChoice = Integer.parseInt(scanner.nextLine()) - 1;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    continue;
                }
                if (seatChoice < 0 || seatChoice >= availableSeats.size()) {
                    System.out.println("Invalid seat selection.");
                    continue;
                }
                String seatSelection = availableSeats.get(seatChoice);
                System.out.print("Special Requests for the Booking (optional, e.g., meal preferences, press Enter to skip): ");
                String specialRequests = scanner.nextLine();
                if (specialRequests.trim().isEmpty()) {
                    specialRequests = "None";
                }
                System.out.print("Number of Passengers: ");
                int numPassengers;
                try {
                    numPassengers = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    continue;
                }
                Booking booking = new Booking(generateBookingReference(), customer, flight, seatSelection, "Reserved", specialRequests);
                for (int i = 0; i < numPassengers; i++) {
                    System.out.println("Passenger " + (i + 1) + " Details:");
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Passport Number: ");
                    String passport = scanner.nextLine();
                    System.out.print("Date of Birth (YYYY-MM-DD): ");
                    String dob = scanner.nextLine();
                    System.out.print("Special Requests (seat): ");
                    String passengerRequests = scanner.nextLine();
                    Passenger passenger = new Passenger(name, passport, dob, passengerRequests);
                    booking.addPassenger(passenger);
                }
                createBookingForCustomer(customer, flight, seatSelection, specialRequests, booking);
                system.createBooking(customer, flight, seatSelection, specialRequests, booking);
            } else if (choice.equals("4")) {
                System.out.print("Booking Reference: ");
                String ref = scanner.nextLine();
                System.out.print("New Seat Class: ");
                String seatClass = scanner.nextLine().toLowerCase();
                if (!seatClass.equals("economy") && !seatClass.equals("business") && !seatClass.equals("first")) {
                    System.out.println("Invalid seat class.");
                    continue;
                }
                String newSeat = seatClass + "-A1"; 
                modifyBooking(ref, newSeat);
            } else if (choice.equals("5")) {
                generateReports();
            } else if (choice.equals("6")) {
                logOut();
                break;
            } else {
                System.out.println("Invalid option.");
            }
        }
    }
}