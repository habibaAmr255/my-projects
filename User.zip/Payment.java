import java.util.UUID;

class Payment {
    private String paymentId;
    private String bookingReference;
    private double amount;
    private String method;
    private String status;
    private String transactionDate;

    public Payment(String bookingReference, double amount, String method, String transactionDate) {
        this.paymentId = UUID.randomUUID().toString();
        this.bookingReference = bookingReference;
        this.amount = amount;
        this.method = method;
        this.status = "Pending";
        this.transactionDate = transactionDate;
    }

    public String getPaymentId() { return paymentId; }
    public String getBookingReference() { return bookingReference; }
    public double getAmount() { return amount; }
    public String getStatus() { return status; }

    
    public boolean validatePaymentDetails() {
        if (method == null || method.trim().isEmpty() || !method.matches("^(Credit Card|Debit Card|PayPal)$")) {
            System.out.println("Invalid payment method. Must be Credit Card, Debit Card, or PayPal.");
            return false;
        }
        if (amount <= 0) {
            System.out.println("Invalid payment amount.");
            return false;
        }
        return true;
    }

    public boolean processPayment() {
        double failureChance = Math.random();
        if (failureChance < 0.1) { 
            status = "Failed";
            System.out.println("Payment failed for booking: " + bookingReference);
            return false;
        }
        status = "Confirmed";
        System.out.println("Payment processed for booking: " + bookingReference);
        return true;
    }


    public void updateStatus(String status) {
        this.status = status;
        System.out.println("Payment status updated to: " + status);
    }
}