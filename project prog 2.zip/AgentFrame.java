import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AgentFrame extends JPanel {
    private BookingSystem system;
    private Agent agent;
    private NavigationManager navManager;
    private JPanel cardPanel;

    public AgentFrame(BookingSystem system, Agent agent, NavigationManager navManager, JPanel cardPanel) {
        this.system = system;
        this.agent = agent;
        this.navManager = navManager;
        this.cardPanel = cardPanel;
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setLayout(new BorderLayout(10, 10));

        // Top panel with Back to Main Menu button
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backToMainButton = new JButton("Back to Main Menu");
        backToMainButton.addActionListener(e -> navManager.showMainPanel());
        topPanel.add(backToMainButton);
        add(topPanel, BorderLayout.NORTH);

        // Main content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        JButton addFlightButton = new JButton("Add Flight");
        addFlightButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, addFlightButton.getPreferredSize().height));
        addFlightButton.addActionListener(new AddFlightActionListener());
        contentPanel.add(addFlightButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton updateFlightButton = new JButton("Update Flight");
        updateFlightButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, updateFlightButton.getPreferredSize().height));
        updateFlightButton.addActionListener(new UpdateFlightActionListener());
        contentPanel.add(updateFlightButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton createBookingButton = new JButton("Create Booking for Customer");
        createBookingButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, createBookingButton.getPreferredSize().height));
        createBookingButton.addActionListener(new CreateBookingActionListener());
        contentPanel.add(createBookingButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, logoutButton.getPreferredSize().height));
        logoutButton.addActionListener(e -> {
            agent.logOut();
            system.currentUser = null;
            navManager.showPanel("Login");
        });
        contentPanel.add(logoutButton);

        add(contentPanel, BorderLayout.CENTER);
    }

    private class AddFlightActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JPanel inputPanel = new JPanel(new GridLayout(8, 2, 10, 10));
            JTextField flightNumberField = new JTextField();
            JTextField airlineField = new JTextField();
            JTextField originField = new JTextField();
            JTextField destinationField = new JTextField();
            JTextField departureField = new JTextField("YYYY-MM-DD HH:MM");
            JTextField seatsField = new JTextField();
            JTextField economyPriceField = new JTextField();
            JComboBox<String> flightTypeCombo = new JComboBox<>(new String[]{"Domestic", "International"});

            inputPanel.add(new JLabel("Flight Number:"));
            inputPanel.add(flightNumberField);
            inputPanel.add(new JLabel("Airline:"));
            inputPanel.add(airlineField);
            inputPanel.add(new JLabel("Origin:"));
            inputPanel.add(originField);
            inputPanel.add(new JLabel("Destination:"));
            inputPanel.add(destinationField);
            inputPanel.add(new JLabel("Departure Time:"));
            inputPanel.add(departureField);
            inputPanel.add(new JLabel("Seats:"));
            inputPanel.add(seatsField);
            inputPanel.add(new JLabel("Economy Price:"));
            inputPanel.add(economyPriceField);
            inputPanel.add(new JLabel("Flight Type:"));
            inputPanel.add(flightTypeCombo);

            int result = JOptionPane.showConfirmDialog(AgentFrame.this, inputPanel, 
                "Add New Flight", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                try {
                    String flightNumber = flightNumberField.getText().trim();
                    String airline = airlineField.getText().trim();
                    String origin = originField.getText().trim();
                    String destination = destinationField.getText().trim();
                    String departure = departureField.getText().trim();
                    int seats = Integer.parseInt(seatsField.getText().trim());
                    double economyPrice = Double.parseDouble(economyPriceField.getText().trim());

                    if (system.flights.stream().anyMatch(f -> f.getFlightNumber().equals(flightNumber))) {
                        JOptionPane.showMessageDialog(AgentFrame.this, 
                            "Flight number already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    double[] prices = {economyPrice, economyPrice * 1.5, economyPrice * 2};
                    Flight flight;
                    if (flightTypeCombo.getSelectedItem().equals("Domestic")) {
                        String discount = JOptionPane.showInputDialog(AgentFrame.this, 
                            "Domestic Discount (e.g., 0.1 for 10%):");
                        String luggage = JOptionPane.showInputDialog(AgentFrame.this, 
                            "Luggage Limit (kg):");
                        double domesticDiscount = Double.parseDouble(discount);
                        double luggageLimit = Double.parseDouble(luggage);
                        flight = new DomesticFlight(flightNumber, airline, origin, destination, 
                            departure, departure, seats, prices, domesticDiscount, luggageLimit);
                    } else {
                        String tax = JOptionPane.showInputDialog(AgentFrame.this, 
                            "International Tax (e.g., 50.0):");
                        double internationalTax = Double.parseDouble(tax);
                        flight = new InternationalFlight(flightNumber, airline, origin, destination, 
                            departure, departure, seats, prices, internationalTax);
                    }

                    system.flights.add(flight);
                    navManager.saveData();
                    JOptionPane.showMessageDialog(AgentFrame.this, 
                        "Flight added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(AgentFrame.this, 
                        "Invalid input format.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private class UpdateFlightActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String flightNumber = JOptionPane.showInputDialog(AgentFrame.this, 
                "Enter Flight Number:");
            if (flightNumber == null || flightNumber.trim().isEmpty()) return;

            Flight flight = system.flights.stream()
                .filter(f -> f.getFlightNumber().equals(flightNumber))
                .findFirst()
                .orElse(null);

            if (flight == null) {
                JOptionPane.showMessageDialog(AgentFrame.this, 
                    "Flight not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
            JTextField departureField = new JTextField(flight.getDepartureTime());
            JTextField arrivalField = new JTextField(flight.getArrivalTime());

            inputPanel.add(new JLabel("New Departure Time:"));
            inputPanel.add(departureField);
            inputPanel.add(new JLabel("New Arrival Time:"));
            inputPanel.add(arrivalField);

            int result = JOptionPane.showConfirmDialog(AgentFrame.this, inputPanel, 
                "Update Flight Schedule", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                flight.updateSchedule(departureField.getText().trim(), arrivalField.getText().trim());
                navManager.saveData();
                JOptionPane.showMessageDialog(AgentFrame.this, 
                    "Flight updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private class CreateBookingActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String customerId = JOptionPane.showInputDialog(AgentFrame.this, 
                "Enter Customer ID:");
            if (customerId == null || customerId.trim().isEmpty()) {
                JOptionPane.showMessageDialog(AgentFrame.this, 
                    "Invalid customer ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Customer selectedCustomer = null;
            for (User user : system.getUsers()) {
                if (user instanceof Customer && ((Customer) user).getCustomerId().equals(customerId)) {
                    selectedCustomer = (Customer) user;
                    break;
                }
            }

            if (selectedCustomer == null) {
                JOptionPane.showMessageDialog(AgentFrame.this, 
                    "Customer not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            BookingFrame bookingPanel = new BookingFrame(system, selectedCustomer, navManager, cardPanel);
            cardPanel.add(bookingPanel, "Booking");
            navManager.addPanel("Booking", bookingPanel);
            navManager.showPanel("Booking");
        }
    }
}