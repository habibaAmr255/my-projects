import java.util.UUID;

class Passenger {
    private String passengerId;
    private String name;
    private String passportNumber;
    private String dateOfBirth;
    private String specialRequests;

    public Passenger(String name, String passportNumber, String dateOfBirth, String specialRequests) {
        this.passengerId = UUID.randomUUID().toString();
        this.name = name;
        this.passportNumber = passportNumber;
        this.dateOfBirth = dateOfBirth;
        this.specialRequests = specialRequests;
    }

    public String getPassengerDetails() {
        return "Passenger: " + name + ", Passport: " + passportNumber + ", DOB: " + dateOfBirth;
    }

    public String getPassengerId() {
        return passengerId != null ? passengerId : "";
    }

    public String getName() {
        return name != null ? name : "";
    }

    public String getPassportNumber() {
        return passportNumber != null ? passportNumber : "";
    }

    public String getDateOfBirth() {
        return dateOfBirth != null ? dateOfBirth : "";
    }

    public String getSpecialRequests() {
        return specialRequests != null ? specialRequests : "";
    }

    public void updateInfo(String name, String passportNumber, String dateOfBirth, String specialRequests) {
        this.name = name;
        this.passportNumber = passportNumber;
        this.dateOfBirth = dateOfBirth;
        this.specialRequests = specialRequests;
        System.out.println("Passenger info updated: " + name);
    }
}