import java.util.Scanner;

class Administrator extends User {
    private String adminId;
    private String securityLevel;

    public Administrator(String userId, String userName, String password, String name, String email, String contactInfo, 
                        String adminId, String securityLevel) {
        super(userId, userName, password, name, email, contactInfo);
        this.adminId = adminId;
        this.securityLevel = securityLevel;
    }

    public boolean setAdminId(String adminId) {
        if (adminId == null || adminId.trim().isEmpty()) {
            System.out.println("Admin ID cannot be null or empty.");
            return false;
        }
        this.adminId = adminId;
        System.out.println("Admin ID set successfully.");
        return true;
    }

    public String getAdminId() {
        return adminId;
    }

    public boolean setSecurityLevel(String securityLevel) {
        if (securityLevel == null || securityLevel.trim().isEmpty()) {
            System.out.println("Security Level cannot be null or empty.");
            return false;
        }
        this.securityLevel = securityLevel;
        System.out.println("Security Level set successfully.");
        return true;
    }

    public String getSecurityLevel() {
        return securityLevel;
    }

    public void createUser(BookingSystem system, Scanner scanner) {
        System.out.println("---- Create New User ----");
        System.out.print("User Type (Customer/Agent/Administrator): ");
        String userType = scanner.nextLine().trim();
        if (!userType.equalsIgnoreCase("Customer") && !userType.equalsIgnoreCase("Agent") && !userType.equalsIgnoreCase("Administrator")) {
            System.out.println("Invalid user type.");
            return;
        }

        System.out.print("User ID: ");
        String userId = scanner.nextLine().trim();
        if (system.getUser(userId) != null) {
            System.out.println("Error: User ID already exists.");
            return;
        }

        System.out.print("Username: ");
        String userName = scanner.nextLine().trim();
        for (User user : system.getUsers()) {
            if (user.getUserName().equals(userName)) {
                System.out.println("Error: Username already exists.");
                return;
            }
        }

        System.out.print("Password: ");
        String password = scanner.nextLine().trim();
        System.out.print("Name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Email: ");
        String email = scanner.nextLine().trim();
        System.out.print("Contact Info: ");
        String contactInfo = scanner.nextLine().trim();

        User newUser = null;
        if (userType.equalsIgnoreCase("Customer")) {
            System.out.print("Customer ID: ");
            String customerId = scanner.nextLine().trim();
            System.out.print("Address: ");
            String address = scanner.nextLine().trim();
            System.out.print("Preferences: ");
            String preferences = scanner.nextLine().trim();
            newUser = new Customer(userId, userName, password, name, email, contactInfo, customerId, address, preferences);
        } else if (userType.equalsIgnoreCase("Agent")) {
            System.out.print("Agent ID: ");
            String agentId = scanner.nextLine().trim();
            System.out.print("Department: ");
            String department = scanner.nextLine().trim();
            System.out.print("Commission: ");
            double commission;
            try {
                commission = Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid commission value.");
                return;
            }
            newUser = new Agent(userId, userName, password, name, email, contactInfo, agentId, department, commission);
        } else if (userType.equalsIgnoreCase("Administrator")) {
            System.out.print("Admin ID: ");
            String adminId = scanner.nextLine().trim();
            System.out.print("Security Level: ");
            String securityLevel = scanner.nextLine().trim();
            newUser = new Administrator(userId, userName, password, name, email, contactInfo, adminId, securityLevel);
        }

        system.users.add(newUser);
        system.saveData();
        System.out.println("User created successfully: " + userName);
    }

    public void modifySystemSettings() {
        System.out.println("System settings modified by admin: " + getName());
    }

    public void viewSystemLogs() {
        System.out.println("Viewing system logs for admin: " + getName());
    }

    public void manageUserAccess(BookingSystem system, Scanner scanner) {
        System.out.println("---- Manage User Access ----");
        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine().trim();
        User user = system.getUser(userId);
        if (user == null) {
            System.out.println("User not found.");
            return;
        }
        System.out.println("User found: " + user.getUserName());
        System.out.print("Action (Enable/Disable): ");
        String action = scanner.nextLine().trim();
        if (action.equalsIgnoreCase("Enable")) {
            System.out.println("User " + user.getUserName() + " enabled.");
        } else if (action.equalsIgnoreCase("Disable")) {
            System.out.println("User " + user.getUserName() + " disabled.");
        } else {
            System.out.println("Invalid action.");
        }
        system.saveData();
    }

    @Override
    public void updateProfile() {
        System.out.println("Admin profile updated successfully for: " + getName());
    }

    @Override
    public void showMenu(BookingSystem system, Scanner scanner) {
        while (true) {
            System.out.println("---- Administrator Menu ----");
            System.out.println("1. Create User");
            System.out.println("2. Modify System Settings");
            System.out.println("3. View System Logs");
            System.out.println("4. Manage User Access");
            System.out.println("5. Update Profile");
            System.out.println("6. Logout");
            System.out.print("Choose: ");
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                createUser(system, scanner);
            } else if (choice.equals("2")) {
                modifySystemSettings();
                system.saveData();
            } else if (choice.equals("3")) {
                viewSystemLogs();
            } else if (choice.equals("4")) {
                manageUserAccess(system, scanner);
            } else if (choice.equals("5")) {
                System.out.print("New Name: ");
                String name = scanner.nextLine();
                System.out.print("New Email: ");
                String email = scanner.nextLine();
                setName(name);
                setEmail(email);
                updateProfile();
                system.saveData();
            } else if (choice.equals("6")) {
                logOut();
                break;
            } else {
                System.out.println("Invalid option.");
            }
        }
    }
}