import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.text.SimpleDateFormat;

public class BookingFrame extends JPanel {
    private BookingSystem system;
    private Customer customer;
    private NavigationManager navManager;
    private JPanel cardPanel;
    private JComboBox<String> seatCombo;
    private JComboBox<String> seatClassCombo;
    private JTextField luggageWeightField;
    private JTextField passportExpiryField;
    private JTable flightTable;
    private List<Flight> flights;

    public BookingFrame(BookingSystem system, Customer customer, NavigationManager navManager, JPanel cardPanel) {
        this.system = system;
        this.customer = customer;
        this.navManager = navManager;
        this.cardPanel = cardPanel;
        this.flights = new ArrayList<>();
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> navManager.showPanel(system.currentUser instanceof Customer ? "Customer" : "Agent"));
        topPanel.add(backButton);

        JButton backToMainButton = new JButton("Back to Main Menu");
        backToMainButton.addActionListener(e -> navManager.showMainPanel());
        topPanel.add(backToMainButton);
        add(topPanel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField originField = new JTextField();
        JTextField destinationField = new JTextField();
        JTextField dateField = new JTextField("YYYY[-MM[-DD]]");
        seatClassCombo = new JComboBox<>(new String[]{"economy", "business", "first"});
        JButton searchButton = new JButton("Search Flights");

        searchPanel.add(new JLabel("Origin:"));
        searchPanel.add(originField);
        searchPanel.add(new JLabel("Destination:"));
        searchPanel.add(destinationField);
        searchPanel.add(new JLabel("Date (YYYY[-MM[-DD]]):"));
        searchPanel.add(dateField);
        searchPanel.add(new JLabel("Seat Class:"));
        searchPanel.add(seatClassCombo);
        searchPanel.add(new JLabel(""));
        searchPanel.add(searchButton);

        add(searchPanel, BorderLayout.NORTH);

        flightTable = new JTable(new Object[][]{}, new String[]{"Flight No", "Airline", "Departure", "Price", "Seats Available"});
        flightTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        TableColumnModel columnModel = flightTable.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(1).setPreferredWidth(150);
        columnModel.getColumn(2).setPreferredWidth(200);
        columnModel.getColumn(3).setPreferredWidth(100);
        columnModel.getColumn(4).setPreferredWidth(100);
        DefaultTableCellRenderer priceRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, 
                                                           boolean hasFocus, int row, int column) {
                if (value instanceof Double) {
                    value = String.format("%.0f", (Double) value);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        };
        columnModel.getColumn(3).setCellRenderer(priceRenderer);
        JScrollPane flightScrollPane = new JScrollPane(flightTable);
        flightScrollPane.setPreferredSize(new Dimension(600, 200));
        add(flightScrollPane, BorderLayout.CENTER);

        JPanel passengerPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        JTextField passengerNameField = new JTextField();
        JTextField passportField = new JTextField();
        JTextField dobField = new JTextField("YYYY-MM-DD");
        JTextField specialRequestsField = new JTextField();
        seatCombo = new JComboBox<>();
        seatCombo.addItem("Select a flight first");
        luggageWeightField = new JTextField();
        passportExpiryField = new JTextField("YYYY-MM-DD");
        JButton confirmButton = new JButton("Confirm Booking");

        passengerPanel.add(new JLabel("Passenger Name:"));
        passengerPanel.add(passengerNameField);
        passengerPanel.add(new JLabel("Passport Number:"));
        passengerPanel.add(passportField);
        passengerPanel.add(new JLabel("Date of Birth:"));
        passengerPanel.add(dobField);
        passengerPanel.add(new JLabel("Special Requests:"));
        passengerPanel.add(specialRequestsField);
        passengerPanel.add(new JLabel("Select Seat:"));
        passengerPanel.add(seatCombo);
        passengerPanel.add(new JLabel("Luggage Weight (kg):"));
        passengerPanel.add(luggageWeightField);
        passengerPanel.add(new JLabel("Passport Expiry (International):"));
        passengerPanel.add(passportExpiryField);
        passengerPanel.add(new JLabel(""));
        passengerPanel.add(confirmButton);

        add(passengerPanel, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> {
            String origin = originField.getText().trim();
            String destination = destinationField.getText().trim();
            String date = dateField.getText().trim();

            if (origin.isEmpty() || destination.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!isValidDateFormat(date)) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid date format. Use YYYY, YYYY-MM, or YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            flights.clear();
            flights.addAll(system.searchFlights(origin, destination, date));
            if (flights.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "No flights found.", "Info", JOptionPane.INFORMATION_MESSAGE);
                seatCombo.removeAllItems();
                seatCombo.addItem("No flights available");
                return;
            }

            Object[][] data = new Object[flights.size()][5];
            for (int i = 0; i < flights.size(); i++) {
                Flight f = flights.get(i);
                String seatClass = seatClassCombo.getSelectedItem() != null ? seatClassCombo.getSelectedItem().toString() : "economy";
                data[i] = new Object[]{f.getFlightNumber(), f.getAirline(), 
                    f.getDepartureTime(), f.calculatePrice(seatClass), 
                    f.getAvailableSeats()};
            }
            flightTable.setModel(new DefaultTableModel(data, 
                new String[]{"Flight No", "Airline", "Departure", "Price", "Seats Available"}));
            updateSeatCombo();
        });

        flightTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && flightTable.getSelectedRow() >= 0) {
                updateSeatCombo();
            }
        });

        seatClassCombo.addActionListener(e -> {
            if (flightTable.getSelectedRow() >= 0) {
                updateSeatCombo();
            }
        });

        confirmButton.addActionListener(e -> {
            int selectedRow = flightTable.getSelectedRow();
            if (selectedRow < 0 || selectedRow >= flights.size()) {
                JOptionPane.showMessageDialog(this, 
                    "Please select a flight.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String name = passengerNameField.getText().trim();
            String passport = passportField.getText().trim();
            String dob = dobField.getText().trim();
            String specialRequests = specialRequestsField.getText().trim();
            String seatSelection = (String) seatCombo.getSelectedItem();
            String luggageWeight = luggageWeightField.getText().trim();
            String passportExpiry = passportExpiryField.getText().trim();

            if (name.isEmpty() || passport.isEmpty() || dob.isEmpty() || 
                seatSelection == null || seatSelection.equals("Select a flight first") || 
                seatSelection.equals("No seats available") || seatSelection.equals("No flights available")) {
                JOptionPane.showMessageDialog(this, 
                    "Please fill all passenger details and select a valid seat.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!isValidDateFormat(dob)) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid date of birth format. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!passportExpiry.isEmpty() && !isValidDateFormat(passportExpiry)) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid passport expiry format. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (specialRequests.isEmpty()) specialRequests = "None";

            Flight selectedFlight = flights.get(selectedRow);

            if (customer != null) {
                for (Booking booking : customer.getBookingHistory()) {
                    if (booking.getFlight().getFlightNumber().equals(selectedFlight.getFlightNumber()) && 
                        (booking.getStatus().equals("Reserved") || booking.getStatus().equals("Confirmed"))) {
                        JOptionPane.showMessageDialog(this, 
                            "You already have a booking for flight " + selectedFlight.getFlightNumber(), 
                            "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            try {
                if (selectedFlight instanceof DomesticFlight) {
                    if (!luggageWeight.isEmpty()) {
                        double weight = Double.parseDouble(luggageWeight);
                        if (!((DomesticFlight) selectedFlight).restrictLuggage(weight)) {
                            JOptionPane.showMessageDialog(this, 
                                "Luggage weight exceeds limit.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                } else if (selectedFlight instanceof InternationalFlight) {
                    if (passportExpiry.isEmpty()) {
                        JOptionPane.showMessageDialog(this, 
                            "Please enter passport expiry date.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (!((InternationalFlight) selectedFlight).checkPassportValidity(passportExpiry)) {
                        JOptionPane.showMessageDialog(this, 
                            "Invalid or expired passport.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                int randomNum = 100000 + (int)(Math.random() * 900000);
                String bookingReference = String.format("%06d", randomNum);
                Booking booking = new Booking(bookingReference, customer, selectedFlight, 
                    seatSelection, "Reserved", specialRequests);
                Passenger passenger = new Passenger(name, passport, dob, specialRequests);
                booking.addPassenger(passenger);

                if (selectedFlight.reserveSeat(seatSelection)) {
                    system.createBooking(customer, selectedFlight, seatSelection, specialRequests, booking);
                    JOptionPane.showMessageDialog(this, 
                        "Booking created successfully. Reference: " + bookingReference, 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                    navManager.showPanel(system.currentUser instanceof Customer ? "Customer" : "Agent");
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Selected seat is not available.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid input format (e.g., luggage weight).", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalStateException ex) {
                JOptionPane.showMessageDialog(this, 
                    ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void updateSeatCombo() {
        seatCombo.removeAllItems();
        if (flights.isEmpty() || flightTable.getSelectedRow() < 0) {
            seatCombo.addItem("Select a flight first");
            return;
        }

        Flight selectedFlight = flights.get(flightTable.getSelectedRow());
        String seatClass = seatClassCombo.getSelectedItem() != null ? seatClassCombo.getSelectedItem().toString() : "economy";
        List<String> availableSeats = selectedFlight.getAvailableSeatsByClass(seatClass);
        if (availableSeats == null || availableSeats.isEmpty()) {
            seatCombo.addItem("No seats available");
        } else {
            for (String seat : availableSeats) {
                seatCombo.addItem(seat);
            }
        }
    }

    private boolean isValidDateFormat(String date) {
        try {
            SimpleDateFormat sdf;
            if (date.matches("\\d{4}")) {
                sdf = new SimpleDateFormat("yyyy");
            } else if (date.matches("\\d{4}-\\d{2}")) {
                sdf = new SimpleDateFormat("yyyy-MM");
            } else if (date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                sdf = new SimpleDateFormat("yyyy-MM-dd");
            } else {
                return false;
            }
            sdf.setLenient(false);
            sdf.parse(date);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}