import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class AdminFrame extends JPanel {
    private BookingSystem system;
    private Administrator admin;
    private NavigationManager navManager;
    private JPanel cardPanel;

    public AdminFrame(BookingSystem system, Administrator admin, NavigationManager navManager, JPanel cardPanel) {
        this.system = system;
        this.admin = admin;
        this.navManager = navManager;
        this.cardPanel = cardPanel;
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backToMainButton = new JButton("Back to Main Menu");
        backToMainButton.addActionListener(e -> navManager.showMainPanel());
        topPanel.add(backToMainButton);
        add(topPanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        JButton addUserButton = new JButton("Add User");
        addUserButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, addUserButton.getPreferredSize().height));
        addUserButton.addActionListener(new AddUserActionListener());
        contentPanel.add(addUserButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton removeUserButton = new JButton("Remove User");
        removeUserButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, removeUserButton.getPreferredSize().height));
        removeUserButton.addActionListener(new RemoveUserActionListener());
        contentPanel.add(removeUserButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton viewBookingsButton = new JButton("View All Bookings");
        viewBookingsButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, viewBookingsButton.getPreferredSize().height));
        viewBookingsButton.addActionListener(new ViewBookingsActionListener());
        contentPanel.add(viewBookingsButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton cancelBookingButton = new JButton("Cancel Booking");
        cancelBookingButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, cancelBookingButton.getPreferredSize().height));
        cancelBookingButton.addActionListener(new CancelBookingActionListener());
        contentPanel.add(cancelBookingButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, logoutButton.getPreferredSize().height));
        logoutButton.addActionListener(e -> {
            admin.logOut();
            system.currentUser = null;
            navManager.showPanel("Login");
        });
        contentPanel.add(logoutButton);

        add(contentPanel, BorderLayout.CENTER);
    }

    private class AddUserActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
            JTextField usernameField = new JTextField();
            JTextField passwordField = new JTextField();
            JTextField nameField = new JTextField();
            JTextField emailField = new JTextField();
            JTextField contactInfoField = new JTextField();
            JComboBox<String> roleCombo = new JComboBox<>(new String[]{"Customer", "Agent", "Administrator"});

            inputPanel.add(new JLabel("Username:"));
            inputPanel.add(usernameField);
            inputPanel.add(new JLabel("Password:"));
            inputPanel.add(passwordField);
            inputPanel.add(new JLabel("Name:"));
            inputPanel.add(nameField);
            inputPanel.add(new JLabel("Email:"));
            inputPanel.add(emailField);
            inputPanel.add(new JLabel("Contact Info:"));
            inputPanel.add(contactInfoField);
            inputPanel.add(new JLabel("Role:"));
            inputPanel.add(roleCombo);

            int result = JOptionPane.showConfirmDialog(AdminFrame.this, inputPanel, 
                "Add New User", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String username = usernameField.getText().trim();
                String password = passwordField.getText().trim();
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String contactInfo = contactInfoField.getText().trim();
                String role = (String) roleCombo.getSelectedItem();

                if (username.isEmpty() || password.isEmpty() || name.isEmpty()) {
                    JOptionPane.showMessageDialog(AdminFrame.this, 
                        "Please fill username, password, and name.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (system.getUsers().stream().anyMatch(u -> u.getUserName().equals(username))) {
                    JOptionPane.showMessageDialog(AdminFrame.this, 
                        "Username already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                User user;
                try {
                    switch (role) {
                        case "Customer":
                            user = new Customer(
                                UUID.randomUUID().toString(), 
                                username, 
                                password, 
                                name, 
                                email.isEmpty() ? "no-email@example.com" : email,
                                contactInfo.isEmpty() ? "no-contact" : contactInfo,
                                UUID.randomUUID().toString(),
                                "Unknown",
                                "None"
                            );
                            break;
                        case "Agent":
                            user = new Agent(
                                UUID.randomUUID().toString(), 
                                username, 
                                password, 
                                name, 
                                email.isEmpty() ? "no-email@example.com" : email,
                                contactInfo.isEmpty() ? "no-contact" : contactInfo,
                                UUID.randomUUID().toString(),
                                "General",
                                0.1
                            );
                            break;
                        case "Administrator":
                            user = new Administrator(
                                UUID.randomUUID().toString(), 
                                username, 
                                password, 
                                name, 
                                email.isEmpty() ? "no-email@example.com" : email,
                                contactInfo.isEmpty() ? "no-contact" : contactInfo,
                                "Administrator",
                                "Administrator"
                            );
                            break;
                        default:
                            return;
                    }

                    system.getUsers().add(user);
                    navManager.saveData();
                    JOptionPane.showMessageDialog(AdminFrame.this, 
                        "User added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(AdminFrame.this, 
                        "Error creating user: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private class RemoveUserActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = JOptionPane.showInputDialog(AdminFrame.this, 
                "Enter Username to Remove:");
            if (username == null || username.trim().isEmpty()) return;

            User user = system.getUsers().stream()
                .filter(u -> u.getUserName().equals(username))
                .findFirst()
                .orElse(null);

            if (user == null) {
                JOptionPane.showMessageDialog(AdminFrame.this, 
                    "User not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            system.getUsers().remove(user);
            navManager.saveData();
            JOptionPane.showMessageDialog(AdminFrame.this, 
                "User removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private class ViewBookingsActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            List<Booking> activeBookings = new ArrayList<>();
            for (Booking b : system.bookings) {
                if (b.getStatus().equals("Reserved") || b.getStatus().equals("Confirmed")) {
                    activeBookings.add(b);
                }
            }

            if (activeBookings.isEmpty()) {
                JOptionPane.showMessageDialog(AdminFrame.this, 
                    "No active bookings found.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] columns = {"Booking Ref", "Flight No", "Customer", "Seat", "Status"};
            Object[][] data = new Object[activeBookings.size()][5];
            for (int i = 0; i < activeBookings.size(); i++) {
                Booking b = activeBookings.get(i);
                String customerName = b.getCustomer() != null ? b.getCustomer().getName() : "Unknown";
                data[i] = new Object[]{b.getBookingReference(), b.getFlight().getFlightNumber(), 
                    customerName, b.getSeatSelection(), b.getStatus()};
            }

            JTable table = new JTable(data, columns);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
            TableColumnModel columnModel = table.getColumnModel();
            columnModel.getColumn(0).setPreferredWidth(100);
            columnModel.getColumn(1).setPreferredWidth(80);
            columnModel.getColumn(2).setPreferredWidth(150);
            columnModel.getColumn(3).setPreferredWidth(80);
            columnModel.getColumn(4).setPreferredWidth(80);
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setPreferredSize(new Dimension(600, 400));
            JOptionPane.showMessageDialog(AdminFrame.this, scrollPane, 
                "All Bookings", JOptionPane.PLAIN_MESSAGE);
        }
    }

    private class CancelBookingActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String ref = JOptionPane.showInputDialog(AdminFrame.this, 
                "Enter Booking Reference:");
            if (ref == null || ref.trim().isEmpty()) {
                JOptionPane.showMessageDialog(AdminFrame.this, 
                    "Invalid booking reference.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Booking bookingToCancel = null;
            for (Booking b : system.bookings) {
                if (b.getBookingReference().equals(ref)) {
                    bookingToCancel = b;
                    break;
                }
            }

            if (bookingToCancel == null) {
                JOptionPane.showMessageDialog(AdminFrame.this, 
                    "Booking not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                system.cancelBooking(ref);
                navManager.saveData();
                JOptionPane.showMessageDialog(AdminFrame.this, 
                    "Booking cancelled successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(AdminFrame.this, 
                    "Error cancelling booking: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}