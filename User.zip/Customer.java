import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Customer extends User {
    private String customerId;
    private String address;
    private List<Booking> bookingHistory;
    private String preferences;

    public Customer(String userId, String userName, String password, String name, String email, String contactInfo, 
                    String customerId, String address, String preferences) {
        super(userId, userName, password, name, email, contactInfo);
        this.customerId = customerId;
        this.address = address;
        this.preferences = preferences;
        this.bookingHistory = new ArrayList<>();
    }

    public boolean setCustomerId(String customerId) {
        if (customerId == null || customerId.trim().isEmpty()) {
            System.out.println("Customer ID cannot be null or empty.");
            return false;
        }
        this.customerId = customerId;
        System.out.println("Customer ID set successfully.");
        return true;
    }

    public String getCustomerId() {
        return customerId;
    }

    public boolean setAddress(String address) {
        if (address == null || address.trim().isEmpty()) {
            System.out.println("Address cannot be null or empty.");
            return false;
        }
        this.address = address;
        System.out.println("Address set successfully.");
        return true;
    }

    public String getAddress() {
        return address;
    }

    public boolean setPreferences(String preferences) {
        if (preferences == null || preferences.trim().isEmpty()) {
            System.out.println("Preferences cannot be null or empty.");
            return false;
        }
        this.preferences = preferences;
        System.out.println("Preferences set successfully.");
        return true;
    }

    public String getPreferences() {
        return preferences;
    }

    public List<Booking> getBookingHistory() {
        return bookingHistory;
    }

    public void createBooking(Flight flight, String seatSelection, String specialRequests) {
        for (Booking booking : bookingHistory) {
            if (booking.getFlight().getFlightNumber().equals(flight.getFlightNumber()) && 
                booking.getStatus().equals("Reserved") || booking.getStatus().equals("Confirmed")) {
                System.out.println("Error: You already have a booking for flight " + flight.getFlightNumber());
                return;
            }
        }

        if (flight instanceof DomesticFlight) {
            System.out.print("Enter luggage weight (kg): ");
            Scanner scanner = new Scanner(System.in);
            double luggageWeight;
            try {
                luggageWeight = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid luggage weight.");
                return;
            }
            if (!((DomesticFlight) flight).restrictLuggage(luggageWeight)) {
                return;
            }
        } else if (flight instanceof InternationalFlight) {
            System.out.print("Enter passport expiry date (YYYY-MM-DD): ");
            Scanner scanner = new Scanner(System.in);
            String expiryDate = scanner.nextLine();
            if (!((InternationalFlight) flight).checkPassportValidity(expiryDate)) {
                return;
            }
        }

        if (flight.reserveSeat(seatSelection)) {
            Booking newBooking = new Booking(generateBookingReference(), this, flight, seatSelection, "Reserved", specialRequests);
            bookingHistory.add(newBooking);
            System.out.println("Booking created successfully. Booking Reference: " + newBooking.getBookingReference());
        } else {
            System.out.println("Cannot create booking: Seat not available.");
        }
    }

    public void viewBooking(String bookingReference) {
        for (Booking booking : bookingHistory) {
            if (booking.getBookingReference().equals(bookingReference)) {
                System.out.println("Booking Details:");
                System.out.println("Booking Reference: " + booking.getBookingReference());
                System.out.println("Flight: " + booking.getFlight().getFlightNumber());
                System.out.println("Status: " + booking.getStatus());
                System.out.println("Seat: " + booking.getSeatSelection());
                return;
            }
        }
        System.out.println("No booking found with reference: " + bookingReference);
    }

    public void cancelBooking(String bookingReference) {
        for (Booking booking : bookingHistory) {
            if (booking.getBookingReference().equals(bookingReference)) {
                booking.cancelBooking();
                System.out.println("Booking cancelled: " + bookingReference);
                return;
            }
        }
        System.out.println("No booking found with reference: " + bookingReference);
    }

    private String generateBookingReference() {
        int randomNum = 100000 + (int)(Math.random() * 900000); 
        return String.format("%06d", randomNum); 
    }

    @Override
    public void updateProfile() {
        System.out.println("Customer profile updated successfully for: " + getName());
    }

    @Override
    public void showMenu(BookingSystem system, Scanner scanner) {
        while (true) {
            System.out.println("---- Customer Menu ----");
            System.out.println("1. Search Flights");
            System.out.println("2. Create Booking");
            System.out.println("3. View Bookings");
            System.out.println("4. Cancel Booking");
            System.out.println("5. Update Profile");
            System.out.println("6. Logout");
            System.out.print("Choose: ");
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                System.out.print("Origin: ");
                String origin = scanner.nextLine();
                System.out.print("Destination: ");
                String destination = scanner.nextLine();
                System.out.print("Date (YYYY-MM-DD): ");
                String date = scanner.nextLine();
                List<Flight> flights = system.searchFlights(origin, destination, date);
                if (flights.isEmpty()) {
                    System.out.println("No flights found.");
                } else {
                    System.out.println("Available Flights:");
                    System.out.println("+-----------------+-------------+-------------------+----------------+");
                    System.out.println("| Flight Number   | Airline     | Departure Time    | Price (Economy)|");
                    System.out.println("+-----------------+-------------+-------------------+----------------+");
                    for (Flight f : flights) {
                        System.out.printf("| %-15s | %-11s | %-17s | $%-13.2f |\n", 
                            f.getFlightNumber(), f.getAirline(), f.getDepartureTime(), f.calculatePrice("economy"));
                    }
                    System.out.println("+-----------------+-------------+-------------------+----------------+");
                }
            } else if (choice.equals("2")) {
                System.out.print("Origin: ");
                String origin = scanner.nextLine();
                System.out.print("Destination: ");
                String destination = scanner.nextLine();
                System.out.print("Date (YYYY-MM-DD): ");
                String date = scanner.nextLine();
                List<Flight> flights = system.searchFlights(origin, destination, date);
                if (flights.isEmpty()) {
                    System.out.println("No flights found.");
                    continue;
                }
                System.out.println("Available Flights:");
                System.out.println("+-----+---------------+-------------+-------------------+");
                System.out.println("| No  | Flight Number | Airline     | Departure Time    |");
                System.out.println("+-----+---------------+-------------+-------------------+");
                for (int i = 0; i < flights.size(); i++) {
                    Flight f = flights.get(i);
                    System.out.printf("| %-3d | %-13s | %-11s | %-17s |\n", 
                        i + 1, f.getFlightNumber(), f.getAirline(), f.getDepartureTime());
                }
                System.out.println("+-----+---------------+-------------+-------------------+");
                System.out.print("Select flight (number): ");
                int flightChoice;
                try {
                    flightChoice = Integer.parseInt(scanner.nextLine()) - 1;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input.");
                    continue;
                }
                if (flightChoice < 0 || flightChoice >= flights.size()) {
                    System.out.println("Invalid selection.");
                    continue;
                }
                Flight selectedFlight = flights.get(flightChoice);
                System.out.print("Seat Class (economy/business/first): ");
                String seatClass = scanner.nextLine().toLowerCase();
                if (!seatClass.equals("economy") && !seatClass.equals("business") && !seatClass.equals("first")) {
                    System.out.println("Invalid seat class.");
                    continue;
                }
                List<String> availableSeats = selectedFlight.getAvailableSeatsByClass(seatClass);
                if (availableSeats.isEmpty()) {
                    System.out.println("No seats available in " + seatClass + " class.");
                    continue;
                }
                System.out.println("Available Seats in " + seatClass + ":");
                for (int i = 0; i < availableSeats.size(); i++) {
                    System.out.println((i + 1) + ". " + availableSeats.get(i));
                }
                System.out.print("Select seat (number): ");
                int seatChoice;
                try {
                    seatChoice = Integer.parseInt(scanner.nextLine()) - 1;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input.");
                    continue;
                }
                if (seatChoice < 0 || seatChoice >= availableSeats.size()) {
                    System.out.println("Invalid seat selection.");
                    continue;
                }
                String seatSelection = availableSeats.get(seatChoice);
                System.out.print("Special Requests for the Booking (optional, e.g., meal preferences");
                String specialRequests = scanner.nextLine();
                if (specialRequests.trim().isEmpty()) {
                    specialRequests = "None";
                }
                System.out.print("Number of Passengers: ");
                int numPassengers;
                try {
                    numPassengers = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input.");
                    continue;
                }
                Booking booking = new Booking(generateBookingReference(), this, selectedFlight, seatSelection, "Reserved", specialRequests);
                for (int i = 0; i < numPassengers; i++) {
                    System.out.println("Passenger " + (i + 1) + " Details:");
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Passport Number: ");
                    String passport = scanner.nextLine();
                    System.out.print("Date of Birth (YYYY-MM-DD): ");
                    String dob = scanner.nextLine();
                    System.out.print("Special Requests (seat): ");
                    String passengerRequests = scanner.nextLine();
                    Passenger passenger = new Passenger(name, passport, dob, passengerRequests);
                    booking.addPassenger(passenger);
                }
                system.createBooking(this, selectedFlight, seatSelection, specialRequests, booking);
                bookingHistory.add(booking);
            } else if (choice.equals("3")) {
                if (bookingHistory.isEmpty()) {
                    System.out.println("No bookings found.");
                } else {
                    System.out.println("Your Bookings:");
                    System.out.println("+-------------------+---------------+-------------+-------------+");
                    System.out.println("| Booking Reference | Flight Number | Status      | Seat        |");
                    System.out.println("+-------------------+---------------+-------------+-------------+");
                    for (Booking b : bookingHistory) {
                        System.out.printf("| %-17s | %-13s | %-11s | %-11s |\n", 
                            b.getBookingReference(), b.getFlight().getFlightNumber(), b.getStatus(), b.getSeatSelection());
                    }
                    System.out.println("+-------------------+---------------+-------------+-------------+");
                }
            } else if (choice.equals("4")) {
                System.out.print("Booking Reference: ");
                String ref = scanner.nextLine();
                cancelBooking(ref);
            } else if (choice.equals("5")) {
                System.out.print("New Name: ");
                String name = scanner.nextLine();
                System.out.print("New Email: ");
                String email = scanner.nextLine();
                System.out.print("New Address: ");
                String address = scanner.nextLine();
                setName(name);
                setEmail(email);
                setAddress(address);
                updateProfile();
            } else if (choice.equals("6")) {
                logOut();
                break;
            } else {
                System.out.println("Invalid option.");
            }
        }
    }
}