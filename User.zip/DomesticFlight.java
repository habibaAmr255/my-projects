class DomesticFlight extends Flight {
    private double domesticDiscount; 
    private double luggageLimit; 

    public DomesticFlight(String flightNumber, String airline, String origin, String destination, String departureTime, 
                         String arrivalTime, int availableSeats, double[] prices, double domesticDiscount, double luggageLimit) {
        super(flightNumber, airline, origin, destination, departureTime, arrivalTime, availableSeats, prices);
        this.domesticDiscount = domesticDiscount;
        this.luggageLimit = luggageLimit;
    }

    public double getDomesticDiscount() {
        return domesticDiscount;
    }

    public void setDomesticDiscount(double domesticDiscount) {
        if (domesticDiscount < 0 || domesticDiscount > 1) {
            System.out.println("Invalid discount value. Must be between 0 and 1.");
            return;
        }
        this.domesticDiscount = domesticDiscount;
        System.out.println("Domestic discount set successfully.");
    }

    public double getLuggageLimit() {
        return luggageLimit;
    }

    public void setLuggageLimit(double luggageLimit) {
        if (luggageLimit <= 0) {
            System.out.println("Luggage limit must be positive.");
            return;
        }
        this.luggageLimit = luggageLimit;
        System.out.println("Luggage limit set successfully.");
    }

    public boolean restrictLuggage(double luggageWeight) {
        if (luggageWeight > luggageLimit) {
            System.out.println("Luggage weight (" + luggageWeight + " kg) exceeds limit (" + luggageLimit + " kg) for domestic flight: " + flightNumber);
            return false;
        }
        System.out.println("Luggage weight acceptable for domestic flight: " + flightNumber);
        return true;
    }

    @Override
    public double calculatePrice(String seatClass) {
        double basePrice = super.calculatePrice(seatClass);
        return basePrice * (1 - domesticDiscount); 
    }
}