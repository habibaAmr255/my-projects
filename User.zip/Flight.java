import java.util.ArrayList;
import java.util.List;

abstract class Flight {
    protected String flightNumber;
    protected String airline;
    protected String origin;
    protected String destination;
    protected String departureTime;
    protected String arrivalTime;
    protected int availableSeats;
    protected double[] prices;
    protected List<String> seats; 
    protected List<String> reservedSeats; 

    public Flight(String flightNumber, String airline, String origin, String destination, String departureTime, 
                  String arrivalTime, int availableSeats, double[] prices) {
        this.flightNumber = flightNumber;
        this.airline = airline;
        this.origin = origin;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.availableSeats = availableSeats;
        this.prices = prices;
        this.seats = new ArrayList<>();
        this.reservedSeats = new ArrayList<>();
        initializeSeats(availableSeats);
    }

    private void initializeSeats(int totalSeats) {
        int seatsPerClass = totalSeats / 3;
        String[] classes = {"economy", "business", "first"};
        for (String seatClass : classes) {
            for (int i = 1; i <= seatsPerClass; i++) {
                seats.add(seatClass + "-" + (char)('A' + (i % 10)) + (i / 10 + 1));
            }
        }
    }

    public String getFlightType() {
        if (this instanceof DomesticFlight) {
            return "Domestic";
        } else if (this instanceof InternationalFlight) {
            return "International";
        }
        return "Unknown";
    }

    public String getFlightNumber() { return flightNumber; }
    public String getAirline() { return airline; }
    public String getOrigin() { return origin; }
    public String getDestination() { return destination; }
    public String getDepartureTime() { return departureTime; }
    public String getArrivalTime() { return arrivalTime; }
    public int getAvailableSeats() { return availableSeats; }

    public List<String> getAvailableSeatsByClass(String seatClass) {
    List<String> seats = new ArrayList<>();
    int start, end;
    int totalSeats = seats.size();
    if (totalSeats == 0) {
        return seats; 
    }
    switch (seatClass.toLowerCase()) {
        case "economy":
            start = 1;
            end = totalSeats / 3;
            break;
        case "business":
            start = totalSeats / 3 + 1;
            end = 2 * totalSeats / 3;
            break;
        case "first":
            start = 2 * totalSeats / 3 + 1;
            end = totalSeats;
            break;
        default:
            return seats;
    }
    for (int i = start; i <= end; i++) {
        String seat = seatClass.charAt(0) + String.valueOf(i);
        if (!reservedSeats.contains(seat)) {
            seats.add(seat);
        }
    }
    return seats;
}

    public boolean checkAvailability() {
        return availableSeats > 0;
    }

    public void updateSchedule(String departureTime, String arrivalTime) {
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        System.out.println("Flight schedule updated for flight: " + flightNumber);
    }

    public double calculatePrice(String seatClass) {
        switch (seatClass.toLowerCase()) {
            case "economy": return prices[0];
            case "business": return prices[1];
            case "first": return prices[2];
            default: return 0.0;
        }
    }

    public boolean reserveSeat(String seat) {
        if (seats.contains(seat) && !reservedSeats.contains(seat) && availableSeats > 0) {
            reservedSeats.add(seat);
            availableSeats--;
            System.out.println("Seat " + seat + " reserved for flight: " + flightNumber);
            return true;
        }
        System.out.println("Seat " + seat + " is not available for flight: " + flightNumber);
        return false;
    }

    public void releaseSeat(String seatSelection) {
    if (reservedSeats.contains(seatSelection)) {
        reservedSeats.remove(seatSelection);
        availableSeats++;
        System.out.println("Seat " + seatSelection + " released for flight: " + flightNumber);
    }
}

}