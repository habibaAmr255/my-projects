import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class BookingSystem {
    List<User> users;
    List<Flight> flights;
    List<Booking> bookings;
    List<Payment> payments;
    private FileManager fileManager;
    private Scanner scanner;
    User currentUser;

    public BookingSystem() {
        users = new ArrayList<>();
        flights = new ArrayList<>();
        bookings = new ArrayList<>();
        payments = new ArrayList<>();
        fileManager = new FileManager();
        scanner = new Scanner(System.in);
        loadData();
    }

    private void loadData() {
        users = fileManager.loadUsers();
        flights = fileManager.loadFlights();
        bookings = fileManager.loadBookings(this);
        fileManager.loadPassengers(this);
    }

    public void saveData() {
        fileManager.saveUsers(users);
        fileManager.saveFlights(flights);
        fileManager.saveBookings(bookings);
        fileManager.savePassengers(bookings);
    }

    public List<Flight> searchFlights(String origin, String destination, String date) {
        List<Flight> availableFlights = new ArrayList<>();
        for (Flight flight : flights) {
            if (flight.getOrigin().equalsIgnoreCase(origin) && 
                flight.getDestination().equalsIgnoreCase(destination) && 
                flight.getDepartureTime().contains(date)) {
                availableFlights.add(flight);
            }
        }
        return availableFlights;
    }
    
    public void createBooking(Customer customer, Flight flight, String seatSelection, String specialRequests, Booking booking) {
        bookings.add(booking);
        customer.getBookingHistory().add(booking);
        System.out.println("Booking created in system: " + booking.getBookingReference());
        saveData();
    }

    public boolean processPayment(String bookingReference, double amount, String method, String transactionDate) {
        Payment payment = new Payment(bookingReference, amount, method, transactionDate);
        if (payment.validatePaymentDetails() && payment.processPayment()) {
            payments.add(payment);
            for (Booking booking : bookings) {
                if (booking.getBookingReference().equals(bookingReference)) {
                    booking.setPaymentStatus("Confirmed");
                    booking.confirmBooking();
                    saveData();
                    return true;
                }
            }
        }
        return false;
    }

    public String generateTicket(String bookingReference) {
        for (Booking booking : bookings) {
            if (booking.getBookingReference().equals(bookingReference)) {
                return "E-Ticket: " + booking.generateItinerary();
            }
        }
        return "No booking found.";
    }

    public List<User> getUsers() {
        return users;
    }

    public User getUser(String userId) {
        for (User user : users) {
            if (user.getUserId().equals(userId)) {
                return user;
            }
        }
        return null;
    }

    public List<Payment> getPayments() {
        return payments;
    }
    
    public void cancelBooking(String ref) {
        for (Booking booking : bookings) {
            if (booking.getBookingReference().equals(ref)) {
                booking.cancelBooking();
                System.out.println("Booking cancelled: " + ref);
                saveData();
                return;
            }
        }
        System.out.println("No booking found with reference: " + ref);

    }
    //  public static void main(String[] args) {
    //     BookingSystem system = new BookingSystem();
    //     Scanner scanner = new Scanner(System.in);
    //     while (true) {
    //         System.out.println("==== Flight Booking System ====");
    //         System.out.println("1. Login");
    //         System.out.println("2. Exit");
    //         System.out.print("Choose: ");
    //         String choice = scanner.nextLine();

    //         if (choice.equals("1")) {
    //             System.out.print("Username: ");
    //             String username = scanner.nextLine();
    //             System.out.print("Password: ");
    //             String password = scanner.nextLine();

    //             boolean loginSuccessful = false;
    //             for (User user : system.users) {
    //                 if (user.login(username, password)) {
    //                     system.currentUser = user;
    //                     user.showMenu(system, scanner);
    //                     system.currentUser = null;
    //                     loginSuccessful = true;
    //                     break;
    //                 }
    //             }
    //             if (!loginSuccessful) {
    //                 System.out.println("Login failed: Invalid username or password.");
    //             }
    //         } else if (choice.equals("2")) {
    //             system.saveData();
    //             System.out.println("Goodbye!");
    //             break;
    //         } else {
    //             System.out.println("Invalid option.");
    //         }
    //     }
    // }
 
    
}