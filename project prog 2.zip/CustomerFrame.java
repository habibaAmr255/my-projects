import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List; 
import javax.swing.*;
import javax.swing.table.TableColumnModel;

public class CustomerFrame extends JPanel {
    private BookingSystem system;
    private Customer customer;
    private NavigationManager navManager;
    private JPanel cardPanel;

    public CustomerFrame(BookingSystem system, Customer customer, NavigationManager navManager, JPanel cardPanel) {
        this.system = system;
        this.customer = customer;
        this.navManager = navManager;
        this.cardPanel = cardPanel;
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backToMainButton = new JButton("Back to Main Menu");
        backToMainButton.addActionListener(e -> navManager.showMainPanel());
        topPanel.add(backToMainButton);
        add(topPanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        JButton searchFlightsButton = new JButton("Search Flights");
        searchFlightsButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, searchFlightsButton.getPreferredSize().height));
        searchFlightsButton.addActionListener(e -> {
            FlightSearchFrame searchPanel = new FlightSearchFrame(system, customer, navManager, cardPanel);
            cardPanel.add(searchPanel, "SearchFlights");
            navManager.addPanel("SearchFlights", searchPanel);
            navManager.showPanel("SearchFlights");
        });
        contentPanel.add(searchFlightsButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton createBookingButton = new JButton("Create Booking");
        createBookingButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, createBookingButton.getPreferredSize().height));
        createBookingButton.addActionListener(e -> {
            BookingFrame bookingPanel = new BookingFrame(system, customer, navManager, cardPanel);
            cardPanel.add(bookingPanel, "Booking");
            navManager.addPanel("Booking", bookingPanel);
            navManager.showPanel("Booking");
        });
        contentPanel.add(createBookingButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton viewBookingsButton = new JButton("View Bookings");
        viewBookingsButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, viewBookingsButton.getPreferredSize().height));
        viewBookingsButton.addActionListener(new ViewBookingsActionListener());
        contentPanel.add(viewBookingsButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton cancelBookingButton = new JButton("Cancel Booking");
        cancelBookingButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, cancelBookingButton.getPreferredSize().height));
        cancelBookingButton.addActionListener(new CancelBookingActionListener());
        contentPanel.add(cancelBookingButton);
        contentPanel.add(Box.createVerticalStrut(10));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, logoutButton.getPreferredSize().height));
        logoutButton.addActionListener(e -> {
            customer.logOut();
            system.currentUser = null;
            navManager.showPanel("Login");
        });
        contentPanel.add(logoutButton);

        add(contentPanel, BorderLayout.CENTER);
    }

    private class ViewBookingsActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            List<Booking> activeBookings = new ArrayList<>();
            for (Booking b : customer.getBookingHistory()) {
                if (b.getStatus().equals("Reserved") || b.getStatus().equals("Confirmed")) {
                    activeBookings.add(b);
                }
            }

            if (activeBookings.isEmpty()) {
                JOptionPane.showMessageDialog(CustomerFrame.this, "No active bookings found.", 
                    "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] columns = {"Booking Ref", "Flight No", "Status", "Seat"};
            Object[][] data = new Object[activeBookings.size()][4];
            for (int i = 0; i < activeBookings.size(); i++) {
                Booking b = activeBookings.get(i);
                data[i] = new Object[]{b.getBookingReference(), b.getFlight().getFlightNumber(), 
                    b.getStatus(), b.getSeatSelection()};
            }

            JTable table = new JTable(data, columns);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
            TableColumnModel columnModel = table.getColumnModel();
            columnModel.getColumn(0).setPreferredWidth(100);
            columnModel.getColumn(1).setPreferredWidth(80);
            columnModel.getColumn(2).setPreferredWidth(80);
            columnModel.getColumn(3).setPreferredWidth(80);
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setPreferredSize(new Dimension(500, 300));
            JOptionPane.showMessageDialog(CustomerFrame.this, scrollPane, 
                "Your Bookings", JOptionPane.PLAIN_MESSAGE);
        }
    }

    private class CancelBookingActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String ref = JOptionPane.showInputDialog(CustomerFrame.this, 
                "Enter Booking Reference:");
            if (ref == null || ref.trim().isEmpty()) {
                JOptionPane.showMessageDialog(CustomerFrame.this, 
                    "Invalid booking reference.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Booking bookingToCancel = null;
            for (Booking booking : customer.getBookingHistory()) {
                if (booking.getBookingReference().equals(ref)) {
                    bookingToCancel = booking;
                    break;
                }
            }

            if (bookingToCancel == null) {
                JOptionPane.showMessageDialog(CustomerFrame.this, 
                    "No booking found with reference: " + ref, "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                system.cancelBooking(ref);
                navManager.saveData();
                JOptionPane.showMessageDialog(CustomerFrame.this, 
                    "Booking cancelled successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(CustomerFrame.this, 
                    "Error cancelling booking: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}