import java.awt.CardLayout;
import java.util.*;
import java.util.logging.Logger;
import javax.swing.*;

public class NavigationManager {
    private static final Logger LOGGER = Logger.getLogger(NavigationManager.class.getName());
    private BookingSystem system;
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private Map<String, JPanel> panels;

    public NavigationManager(BookingSystem system) {
        this.system = system;
        this.panels = new HashMap<>();
    }

    public void setCardLayout(CardLayout cardLayout, JPanel cardPanel) {
        this.cardLayout = cardLayout;
        this.cardPanel = cardPanel;
    }

    public void addPanel(String name, JPanel panel) {
        panels.put(name, panel);
    }

    public void showPanel(String name) {
        if (cardLayout != null && cardPanel != null && panels.containsKey(name)) {
            cardLayout.show(cardPanel, name);
        } else {
            if (panels.containsKey("Login")) {
                cardLayout.show(cardPanel, "Login");
            } else {
                LOGGER.warning("Attempted to show non-existent panel: " + name + ". No Login panel available.");
                JOptionPane.showMessageDialog(null, 
                    "Panel not found: " + name, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void showMainPanel() {
        if (system.currentUser == null) {
            showPanel("Login");
        } else if (system.currentUser instanceof Customer) {
            showPanel("Customer");
        } else if (system.currentUser instanceof Agent) {
            showPanel("Agent");
        } else if (system.currentUser instanceof Administrator) {
            showPanel("Admin");
        } else {
            LOGGER.warning("Unknown user type. Redirecting to Login.");
            showPanel("Login");
        }
    }

    public void saveData() {
        try {
            system.saveData();
            LOGGER.info("Data saved successfully to txt files.");
        } catch (Exception ex) {
            LOGGER.severe("Error saving data: " + ex.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Error saving data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}