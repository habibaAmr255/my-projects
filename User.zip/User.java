import java.util.Scanner;

abstract class User {
    private String userId;
    private String userName;
    private String password;
    private String name;
    private String email;
    private String contactInfo;
    

    public User(String userId, String userName, String password, String name, String email, String contactInfo) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.name = name;
        this.email = email;
        this.contactInfo = contactInfo;
    }

    public boolean setUserId(String userId) {
        if (userId == null || userId.trim().isEmpty()) {
            System.out.println("User ID cannot be null or empty.");
            return false;
        }
        this.userId = userId;
        System.out.println("User ID set successfully.");
        return true;
    }

    public String getUserId() {
        return userId;
    }

    public boolean setUserName(String userName) {
        if (userName == null || userName.trim().isEmpty()) {
            System.out.println("Username cannot be null or empty.");
            return false;
        }
        this.userName = userName;
        System.out.println("Username set successfully.");
        return true;
    }

    public String getUserName() {
        return userName;
    }

    public boolean setPassword(String password) {
        if (password == null) {
            System.out.println("Password cannot be null.");
            return false;
        }
        if (password.length() < 6) {
            System.out.println("Password must be at least 6 characters long.");
            return false;
        }

        boolean hasLetter = false;
        boolean hasDigit = false;

        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) {
                hasLetter = true;
            }
            if (Character.isDigit(c)) {
                hasDigit = true;
            }
        }

        if (!hasLetter || !hasDigit) {
            System.out.println("Password must contain both letters and numbers.");
            return false;
        }

        this.password = password;
        System.out.println("Password set successfully.");
        return true;
    }

    public String getPassword() {
        return password;
    }

    public boolean setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            System.out.println("Name cannot be null or empty.");
            return false;
        }
        this.name = name;
        System.out.println("Name set successfully.");
        return true;
    }

    public String getName() {
        return name;
    }

    public boolean setEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            System.out.println("Email cannot be null or empty.");
            return false;
        }
        if (!email.contains("@") || !email.contains(".")) {
            System.out.println("Invalid email format. Must contain '@' and '.'.");
            return false;
        }
        this.email = email;
        System.out.println("Email set successfully.");
        return true;
    }

    public String getEmail() {
        return email;
    }

    public boolean setContactInfo(String contactInfo) {
        if (contactInfo == null || contactInfo.trim().isEmpty()) {
            System.out.println("Contact information cannot be null or empty.");
            return false;
        }
        this.contactInfo = contactInfo;
        System.out.println("Contact information set successfully.");
        return true;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public boolean login(String username, String password) {
        if (username.equals(getUserName()) && password.equals(getPassword())) {
            String userType = this instanceof Customer ? "customer" : this instanceof Agent ? "agent" : "administrator";
            System.out.println("Login successful for " + userType + ": " + getName());
            return true;
        }
        return false;
    }
    public void logOut() {
        System.out.println("User logged out successfully.");
    }
    public abstract void updateProfile();
    public abstract void showMenu(BookingSystem system, Scanner scanner); 
}