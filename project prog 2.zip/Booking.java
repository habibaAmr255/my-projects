import java.util.ArrayList;
import java.util.List;

class Booking {
    private String bookingReference;
    private Customer customer;
    private Flight flight;
    private List<Passenger> passengers;
    private String seatSelection;
    private String status;
    private String paymentStatus;
    private String specialRequests;

    public Booking(String bookingReference, Customer customer, Flight flight, String seatSelection, String status, String specialRequests) {
        this.bookingReference = bookingReference;
        this.customer = customer;
        this.flight = flight;
        this.passengers = new ArrayList<>();
        this.seatSelection = seatSelection;
        this.status = status;
        this.paymentStatus = "Pending";
        this.specialRequests = specialRequests;
    }

    public String getBookingReference() {
        return bookingReference;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Flight getFlight() {
        return flight;
    }

    public List<Passenger> getPassengers() {
        return passengers;
    }

    public void addPassenger(Passenger passenger) {
        passengers.add(passenger);
    }

    public String getSeatSelection() {
        return seatSelection;
    }

    public String getStatus() {
        return status;
    }

    public String getPaymentStatus() {
        return paymentStatus != null ? paymentStatus : "Pending";
    }

    public void setPaymentStatus(String paymentStatus) {
        if (paymentStatus == null || !(paymentStatus.equals("Pending") || paymentStatus.equals("Confirmed") || paymentStatus.equals("Failed"))) {
            System.out.println("Invalid payment status: " + paymentStatus + ". Setting to Pending.");
            this.paymentStatus = "Pending";
        } else {
            this.paymentStatus = paymentStatus;
        }
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void confirmBooking() {
        this.status = "Confirmed";
    }

    public void cancelBooking() {
        this.status = "Cancelled";
    }

    public double calculateTotalPrice() {
        return flight.calculatePrice(seatSelection.split("-")[0]) * passengers.size();
    }

    public String generateItinerary() {
        return "Booking: " + bookingReference + ", Flight: " + flight.getFlightNumber() + ", Status: " + status;
    }
}
