import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

public class FlightSearchFrame extends JPanel {
    private BookingSystem system;
    private Customer customer;
    private NavigationManager navManager;
    private JPanel cardPanel;

    public FlightSearchFrame(BookingSystem system, Customer customer, NavigationManager navManager, JPanel cardPanel) {
        this.system = system;
        this.customer = customer;
        this.navManager = navManager;
        this.cardPanel = cardPanel;
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> navManager.showPanel("Customer"));
        topPanel.add(backButton);

        JButton backToMainButton = new JButton("Back to Main Menu");
        backToMainButton.addActionListener(e -> navManager.showMainPanel());
        topPanel.add(backToMainButton);
        add(topPanel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField originField = new JTextField(20);
        JTextField destinationField = new JTextField(20);
        JTextField dateField = new JTextField("YYYY[-MM[-DD]]", 20);
        JButton searchButton = new JButton("Search");

        searchPanel.add(new JLabel("Origin:"));
        searchPanel.add(originField);
        searchPanel.add(new JLabel("Destination:"));
        searchPanel.add(destinationField);
        searchPanel.add(new JLabel("Date (YYYY[-MM[-DD]]):"));
        searchPanel.add(dateField);
        searchPanel.add(new JLabel(""));
        searchPanel.add(searchButton);

        add(searchPanel, BorderLayout.NORTH);

        JTable table = new JTable(new Object[][]{}, new String[]{"Flight No", "Airline", "Departure", "Price", "Seats Available"});
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(1).setPreferredWidth(150);
        columnModel.getColumn(2).setPreferredWidth(200);
        columnModel.getColumn(3).setPreferredWidth(100);
        columnModel.getColumn(4).setPreferredWidth(100);
        DefaultTableCellRenderer priceRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, 
                                                           boolean hasFocus, int row, int column) {
                if (value instanceof Double) {
                    value = String.format("%.2f", (Double) value);
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        };
        columnModel.getColumn(3).setCellRenderer(priceRenderer);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(600, 300));
        add(scrollPane, BorderLayout.CENTER);

        // Search button action
        searchButton.addActionListener(e -> {
            String origin = originField.getText().trim();
            String destination = destinationField.getText().trim();
            String date = dateField.getText().trim();

            if (origin.isEmpty() || destination.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!isValidDateFormat(date)) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid date format. Use YYYY, YYYY-MM, or YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            List<Flight> flights = system.searchFlights(origin, destination, date);
            if (flights.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "No flights found.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            Object[][] data = new Object[flights.size()][5];
            for (int i = 0; i < flights.size(); i++) {
                Flight f = flights.get(i);
                data[i] = new Object[]{f.getFlightNumber(), f.getAirline(), 
                    f.getDepartureTime(), f.calculatePrice("economy"), f.getAvailableSeats()};
            }
            table.setModel(new javax.swing.table.DefaultTableModel(data, 
                new String[]{"Flight No", "Airline", "Departure", "Price", "Seats Available"}));
        });
    }

    private boolean isValidDateFormat(String date) {
        try {
            SimpleDateFormat sdf;
            if (date.matches("\\d{4}")) {
                sdf = new SimpleDateFormat("yyyy");
            } else if (date.matches("\\d{4}-\\d{2}")) {
                sdf = new SimpleDateFormat("yyyy-MM");
            } else if (date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                sdf = new SimpleDateFormat("yyyy-MM-dd");
            } else {
                return false;
            }
            sdf.setLenient(false);
            sdf.parse(date);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}