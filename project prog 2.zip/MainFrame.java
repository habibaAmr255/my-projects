import java.awt.*;
import java.awt.event.*;
import java.awt.CardLayout;
import javax.swing.*;
import java.util.UUID;

public class MainFrame extends JFrame {
    private BookingSystem system;
    private NavigationManager navManager;
    private CardLayout cardLayout;
    private JPanel cardPanel;

    public MainFrame(BookingSystem system, NavigationManager navManager) {
        this.system = system;
        this.navManager = navManager;
        setTitle("Flight Booking System");
        setMinimumSize(new Dimension(600, 400));
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        add(cardPanel);

        navManager.setCardLayout(cardLayout, cardPanel);

        JMenuBar menuBar = new JMenuBar();
        JMenu navigationMenu = new JMenu("Navigation");
        
        JMenuItem homeItem = new JMenuItem("Home");
        homeItem.addActionListener(e -> navManager.showMainPanel());
        navigationMenu.add(homeItem);

        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.addActionListener(e -> {
            if (system.currentUser != null) {
                system.currentUser.logOut();
                system.currentUser = null;
            }
            navManager.showPanel("Login");
        });
        navigationMenu.add(logoutItem);

        menuBar.add(navigationMenu);
        setJMenuBar(menuBar);

        if (system.getUsers() == null || system.getUsers().isEmpty()) {
            Administrator defaultAdmin = new Administrator(
                UUID.randomUUID().toString(),
                "admin",
                "admin123",
                "Default Admin",
                "admin@example.com",
                "1234567890",
                "Administrator",
                "Administrator"
            );
            system.getUsers().add(defaultAdmin);
            navManager.saveData();
        }

        JPanel loginPanel = createLoginPanel();
        cardPanel.add(loginPanel, "Login");
        navManager.addPanel("Login", loginPanel);

        pack();
        setVisible(true);
        navManager.showPanel("Login");
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField usernameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        panel.add(passwordField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(MainFrame.this, 
                    "Please enter username and password.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                boolean loginSuccessful = false;
                for (User user : system.getUsers()) {
                    if (user.getUserName().equals(username) && user.login(username, password)) {
                        system.currentUser = user;
                        loginSuccessful = true;

                        if (user instanceof Customer) {
                            CustomerFrame customerPanel = new CustomerFrame(system, (Customer) user, navManager, cardPanel);
                            cardPanel.add(customerPanel, "Customer");
                            navManager.addPanel("Customer", customerPanel);
                            navManager.showPanel("Customer");
                        } else if (user instanceof Agent) {
                            AgentFrame agentPanel = new AgentFrame(system, (Agent) user, navManager, cardPanel);
                            cardPanel.add(agentPanel, "Agent");
                            navManager.addPanel("Agent", agentPanel);
                            navManager.showPanel("Agent");
                        } else if (user instanceof Administrator) {
                            AdminFrame adminPanel = new AdminFrame(system, (Administrator) user, navManager, cardPanel);
                            cardPanel.add(adminPanel, "Admin");
                            navManager.addPanel("Admin", adminPanel);
                            navManager.showPanel("Admin");
                        }
                        break;
                    }
                }

                if (!loginSuccessful) {
                    JOptionPane.showMessageDialog(MainFrame.this, 
                        "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(MainFrame.this, 
                    "Error during login: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(e -> {
            try {
                navManager.saveData();
                System.exit(0);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(MainFrame.this, 
                    "Error saving data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);

        return panel;
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            BookingSystem system = new BookingSystem();
            NavigationManager navManager = new NavigationManager(system);
            new MainFrame(system, navManager);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, 
                "Error initializing system: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}